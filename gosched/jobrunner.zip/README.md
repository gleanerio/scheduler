Gleaner Exec runner


[Background jobs in linux](https://www.tecmint.com/run-linux-command-process-in-background-detach-process/)
[exec-command](https://zetcode.com/golang/exec-command/)

